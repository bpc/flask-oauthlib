# -*- coding: utf-8 -*-

NAME = 'Flask-OAuthlib'

VERSION = "0.3.0lazyconfig"

AUTHOR = "Hsiaoming Yang <me@lepture.com>"

REPOSITORY = 'https://github.com/lepture/flask-oauthlib'

ISSUE_TRACKER = 'https://github.com/lepture/flask-oauthlib/issues'

LICENSE = 'BSD 3'
